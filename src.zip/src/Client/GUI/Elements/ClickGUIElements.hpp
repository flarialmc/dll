﻿#pragma once

#include "../../Module/Modules/Module.hpp"

class ClickGUIElements
{
public:
    static void ModCard(const float x, float y, Module* mod, const std::string iconpath, const float width = 160, const float height = 100);
};