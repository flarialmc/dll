
#pragma once
#include "../Event.hpp"
#include "../Cancellable.hpp"

class RenderEvent : public Event {



};