﻿#pragma once
#include "Hook/Manager.hpp"
#include "Module/Manager.hpp"

class Client
{
public:
    static void initialize();
    static bool disable;
};
